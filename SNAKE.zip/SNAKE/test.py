import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
plt.figure()
plt.plot(houseDataSurfaceOne, houseDataLoyerOne, markersize=1)
plt.plot(houseDataSurfaceTwo, houseDataLoyerTwo, markersize=1)
plt.plot(houseDataSurfaceThree, houseDataLoyerThree, markersize=1)
plt.plot(houseDataSurfaceFour, houseDataLoyerFour, markersize=1)
plt.plot(houseDataSurfaceFive, houseDataLoyerFive, markersize=1)
plt.plot([0, 400], [0, 25000], markersize=1, color="#000000")
plt.xlabel("Surface")
plt.ylabel("Loyer")

plt.show()
