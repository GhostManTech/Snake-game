try:
	import turtle, sys, random as r, os as command, time as t, platform, ctypes
	from tkinter import messagebox
except ImportError:
	print("Erreur d'importation des modules supplémentaires...")
except Exception as error:
	print("[ERROR] : {}".format(error))
else:
	# Définition des propriétés de la fenêtre
	width = 600
	height = 600
	size = ctypes.windll.user32
	screen = size.GetSystemMetrics(0), size.GetSystemMetrics(1)
	x = (screen[0] // 2) - (width // 2)
	y = (screen[1] // 2) - (height // 2)
	windowProperty = turtle.Screen().getcanvas().winfo_toplevel()
	windowProperty.resizable(width=False, height=False)

	# Définition de la fenêtre du jeu
	window = turtle.Screen()
	window.title("START GAME BY GhostManTech")
	window.setup(width, height, x, y)
	def functionStart():
		turtle.hideturtle()
		turtle.tracer(0)
		turtle.speed(0)
		turtle.bgcolor("#111111")
		turtle.pencolor("#FFFFFF")
		turtle.up()
		turtle.goto(-10, 200)
		turtle.down()
		turtle.write("SNAKE BY GhostManTech", align="center", font=("Verdana", 20))
		turtle.up()
		turtle.goto(-10, -50)
		turtle.down()
		turtle.write("PRESS ENTER TO START THE GAME !", align="center", font=("Verdana", 18))
	functionStart()
	snakeHead = turtle.Turtle()

        # Variables du jeu qui ne sont pas des constantes (minuscules)
	square = []
	game = True
	delay = 0.1
	scoreGame = 0
                        
	
	# Fonction de déplacement du serpent
	def move():
		global snakeHead
		if snakeHead.direction == "up":
			y = snakeHead.ycor()
			snakeHead.sety(y + 20)
		if snakeHead.direction == "down":
			y = snakeHead.ycor()
			snakeHead.sety(y - 20)
		if snakeHead.direction == "left":
			x = snakeHead.xcor()
			snakeHead.setx(x - 20)
		if snakeHead.direction == "right":
			x = snakeHead.xcor()
			snakeHead.setx(x + 20)

	# Recirection des instructions clavier vers la fonction de déplacement
	def goUp():
		global snakeHead
		snakeHead.direction = "up"
	def goDown():
		global snakeHead
		snakeHead.direction = "down"
	def goLeft():
		global snakeHead
		snakeHead.direction = "left"
	def goRight():
		global snakeHead
		snakeHead.direction = "right"
	def increaseDelay():
		global delay
		if delay + 0.02 <= 2: delay += 0.02
	def decreaseDelay():
		global delay
		if delay - 0.02 > 0: delay -= 0.02

	def functionGame():
		# Définition des variables globales
		global square, game, delay, scoreGame, window, snakeHead

		# Rafraîchissement total de la fenêtre
		window.reset()
		window.title("SNAKE GAME | SCORE : 0")
		window.bgcolor("#FFFFFF")
		turtle.hideturtle()
		turtle.tracer(0)
		
		# Définition des propriétés des propriétés du serpent
		snakeHead.speed(0)
		snakeHead.shape("square")
		snakeHead.color("#000000")
		snakeHead.penup()
		snakeHead.goto(0, 0)
		snakeHead.direction = "stop"
		
		# Définition de la forme et de la couleur de la nourriture du serpent 
		colorSnakeFood = ["#00FF00", "#a8328f", "#0eb9e8", "#FF00FF", "#FF0000"]
		color  = r.choice(colorSnakeFood)
		snakeFood = turtle.Turtle()
		snakeFood.speed(0)
		snakeFood.shape("circle")
		snakeFood.color(color)
		snakeFood.penup()
		snakeFood.goto(0, 100)
		
		# Éxécution de fonctions aux événements clavier
		window.listen()
		window.onkeypress(goUp, "z")
		window.onkeypress(goDown, "s")
		window.onkeypress(goLeft, "q")
		window.onkeypress(goRight, "d")
		window.onkeypress(increaseDelay, "-")
		window.onkeypress(decreaseDelay, "+")
		window.onkeypress(goUp, "Up")
		window.onkeypress(goDown, "Down")
		window.onkeypress(goLeft, "Left")
		window.onkeypress(goRight, "Right")
		window.onkeypress(None, "Return")
		
		# Boucle principale du jeu
		while game:
			if game == True:
				# Définition des nouvelles propriétés du jeu quand il essaie de dépasser les limites de la toile
				if snakeHead.xcor() > 280 or snakeHead.ycor() > 280 or snakeHead.ycor() < -280 or snakeHead.xcor() < -280:
					t.sleep(0.5)
					snakeHead.goto(0, 0)
					scoreGame = 0
					window.title("SNAKE GAME | SCORE : {}".format(scoreGame))
					snakeHead.direction = "stop"
					for newSquareSnake in square:
						newSquareSnake.goto(1000, 1000)
					square = []
					snakeFood.goto(0, 100)
					delay = 0.1
					snakeHead.color("#000000")
				# Modification du comportement du serpent quant-il se mange la queue
				for newSquareSnake in square:
					if newSquareSnake.distance(snakeHead) == 0:
						t.sleep(0.5)
						snakeHead.goto(0, 0)
						snakeHead.direction = "stop"
						for newSquareSnake in square:
							newSquareSnake.goto(1000, 1000)
						scoreGame = 0
						window.title("SNAKE GAME | SCORE : {}".format(scoreGame))
						square = []
						snakeFood.goto(0, 100)
						dalay = 0.1
						snakeHead.color("#000000")
				# Agrandissement de la taille du serpent quand il mange une pomme
				if snakeHead.distance(snakeFood) == 0:
					snakeHead.color(color)
					newSquareSnake = turtle.Turtle()
					newSquareSnake.speed(0)
					newSquareSnake.shape("square")
					newSquareSnake.color("#000000")
					posX = [-260, -240, -220, -200, -180, -160, -140, -120, -100, -80, -60, -40, -20, 0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240]
					posY = [-260, -240, -220, -200, -180, -160, -140, -120, -100, -80, -60, -40, -20, 0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240]
					x = r.choice(posX)
					y = r.choice(posY)
					colorSnakeFood = ["#00FF00", "#a8328f", "#0eb9e8", "#FF00FF", "#FF0000"]
					color  = r.choice(colorSnakeFood)
					snakeFood.color(color)
					shape = ["circle", "square"]
					choice = r.choice(shape)
					snakeFood.shape(choice)
					snakeFood.goto(x, y)
					newSquareSnake.penup()
					square.append(newSquareSnake)
					scoreGame += 2
					window.title("SNAKE GAME | SCORE : {}".format(scoreGame))
					if scoreGame % 10 == 0 and scoreGame - 0.01 > 0:
						delay -= 0.005
					if scoreGame >= 100 and scoreGame % 100 == 0:
						messagebox.showinfo(title="YOU WON !!!", message="Bravo, vous avez un score de {}".format(scoreGame), icon="warning")

				# Nouvelles propriétes qui permetent de faire tenir le corps du serpent avec sa tête
				for k in range(len(square)-1, 0, -1):
					x = square[k-1].xcor()
					y = square[k-1].ycor()
					square[k].goto(x, y)
				if len(square) > 0:
					x = snakeHead.xcor()
					y = snakeHead.ycor()
					square[0].goto(x, y)
				move()
				t.sleep(delay)
				window.update()
	window.listen()
	window.onkeypress(functionGame, "Return")
	window.mainloop()
