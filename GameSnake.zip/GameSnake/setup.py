try:
	from cx_Freeze import setup, Executable
except ImportError:
	print("Erreur d'importation du modulme nécessaire...")
except Exception as error:
	print("[ERROR] : {}".format(error))
else:
	setup(name="snake", version="0.1", description="Le jeu du snake développé en python", executables = [Executable("main.py", icon="LIB/icon.ico")])




finally:
	print("Fin du programme...")